module.exports = {
    google: {
        clientID:'713811173783-ptr0c3mo5mih8o0t25m0ds9o0d3vkuoo.apps.googleusercontent.com',
        clientSecret: 'dNnmyBsaTecBsSEWaHZ7RNcM',
    },
    session:{
        cookieKeys:'codingIsKindaThrash'
    },
    mail: {
        user:'projectsemailaddress@gmail.com',
        pass:'Michael66*',
        host:'smtp.gmail.com'
    }
};

// mail: {
//     user:'no-reply@vunanacoss.com',
//     pass:'noreply@12345',
//     host:'mail.vunanacoss.com'
// }